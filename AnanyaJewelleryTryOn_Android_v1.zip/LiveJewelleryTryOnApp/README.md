# Ananya Jewellery Try-On — Android v1

Native Android prototype with:
- Front camera live preview
- Google ML Kit face tracking
- Actual uploaded earring asset with transparent background
- Earring follows left/right ear landmarks
- Change Earring button
- Take Photo saves the try-on image to Pictures/AnanyaJewellery

Build with Android Studio or the included GitHub Actions workflow.
