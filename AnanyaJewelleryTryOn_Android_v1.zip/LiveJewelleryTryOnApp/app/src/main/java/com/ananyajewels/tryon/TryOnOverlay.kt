package com.ananyajewels.tryon

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import com.google.mlkit.vision.face.Face

class TryOnOverlay(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val earring = BitmapFactory.decodeResource(resources, R.drawable.earring_actual)
    private var face: Face? = null
    private var sx = 1f
    private var sy = 1f
    private var style = 0

    fun nextStyle() { style = (style + 1) % 3; invalidate() }

    fun updateFace(f: Face, viewW: Int, viewH: Int, imageW: Int, imageH: Int) {
        face = f
        sx = viewW.toFloat() / imageW.coerceAtLeast(1)
        sy = viewH.toFloat() / imageH.coerceAtLeast(1)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val f = face ?: return
        val left = f.getLandmark(7)?.position
        val right = f.getLandmark(8)?.position
        if (left != null) drawEarring(canvas, left.x * sx, left.y * sy, f.headEulerAngleY)
        if (right != null) drawEarring(canvas, right.x * sx, right.y * sy, -f.headEulerAngleY)
    }

    private fun drawEarring(canvas: Canvas, anchorX: Float, anchorY: Float, angleY: Float) {
        if (earring == null) return
        val faceW = face?.boundingBox?.width()?.toFloat()?.times(sx) ?: 220f
        val sizeFactor = when (style) { 0 -> 0.20f; 1 -> 0.24f; else -> 0.28f }
        val targetW = (faceW * sizeFactor).coerceIn(65f, 165f)
        val targetH = targetW * earring.height / earring.width
        val scale = targetW / earring.width.toFloat()
        val matrix = Matrix()
        matrix.postScale(scale, scale)
        matrix.postRotate((angleY * 0.35f).coerceIn(-18f, 18f))
        matrix.postTranslate(anchorX - targetW / 2f, anchorY - 8f)
        canvas.drawBitmap(earring, matrix, paint)
    }
}
